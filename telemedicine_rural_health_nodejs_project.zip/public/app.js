const doctorList = document.getElementById("doctorList");
const doctorSelect = document.getElementById("doctorSelect");
const form = document.getElementById("bookingForm");
const result = document.getElementById("result");

async function loadDoctors() {
  const res = await fetch("/api/doctors");
  const doctors = await res.json();

  doctorList.innerHTML = doctors.map(d => `
    <article class="doctor-card">
      <span class="badge">${d.specialty}</span>
      <h3>${d.name}</h3>
      <p>Available: ${d.availability}</p>
      <a class="btn" href="#booking" onclick="selectDoctor(${d.id})">Book</a>
    </article>
  `).join("");

  doctorSelect.innerHTML = '<option value="">Select a doctor</option>' +
    doctors.map(d => `<option value="${d.id}">${d.name} — ${d.specialty}</option>`).join("");
}

function selectDoctor(id) {
  doctorSelect.value = id;
  document.getElementById("booking").scrollIntoView({behavior:"smooth"});
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());

  const res = await fetch("/api/appointments", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(data)
  });

  const body = await res.json();
  if (!res.ok) {
    result.className = "form-message";
    result.textContent = body.message;
    return;
  }

  result.className = "form-message";
  result.innerHTML = `Appointment #${body.id} scheduled with ${body.doctor} on ${body.date} at ${body.time}.`;
  form.reset();
});

loadDoctors();