const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const doctors = [
  { id: 1, name: "Dr. Ananya Rao", specialty: "General Medicine", availability: "09:00 AM – 01:00 PM" },
  { id: 2, name: "Dr. Ravi Kumar", specialty: "Pediatrics", availability: "02:00 PM – 05:00 PM" },
  { id: 3, name: "Dr. Meera Shah", specialty: "Dermatology", availability: "10:00 AM – 01:00 PM" }
];

let appointments = [];

app.get("/api/doctors", (req, res) => res.json(doctors));

app.get("/api/appointments", (req, res) => res.json(appointments));

app.post("/api/appointments", (req, res) => {
  const { patientName, phone, doctorId, date, time, symptoms } = req.body;

  if (!patientName || !phone || !doctorId || !date || !time) {
    return res.status(400).json({ message: "Please fill all required fields." });
  }

  const doctor = doctors.find(d => d.id === Number(doctorId));
  if (!doctor) return res.status(404).json({ message: "Doctor not found." });

  const appointment = {
    id: appointments.length + 1,
    patientName,
    phone,
    doctor: doctor.name,
    specialty: doctor.specialty,
    date,
    time,
    symptoms: symptoms || "Not provided",
    status: "Scheduled"
  };

  appointments.push(appointment);
  res.status(201).json(appointment);
});

app.listen(PORT, () => {
  console.log(`Telemedicine app running at http://localhost:${PORT}`);
});